# AI Video Maker Android V3

Fixes:
- Real line breaks instead of visible \n
- Cleaner scene formatting
- Per-scene copy buttons
- Updated video-generator button to Lightricks LTX Video Fast Space
- Version 3.0

The video generator is an external web service; availability can change.
