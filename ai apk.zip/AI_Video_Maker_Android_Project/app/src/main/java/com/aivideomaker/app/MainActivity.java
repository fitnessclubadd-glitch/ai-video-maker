package com.aivideomaker.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root; EditText script; TextView status;
    int pad=18;
    @Override public void onCreate(Bundle b){super.onCreate(b); build();}
    TextView title(String t,int sp){TextView v=new TextView(this);v.setText(t);v.setTextColor(Color.WHITE);v.setTextSize(sp);v.setPadding(pad,pad,pad,8);return v;}
    Button btn(String t){Button b=new Button(this);b.setText(t);b.setAllCaps(false);return b;}
    void build(){
      root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(16,12,16,20);root.setBackgroundColor(Color.rgb(8,10,15));
      ScrollView sv=new ScrollView(this);sv.addView(root);
      root.addView(title("AI VIDEO MAKER",24)); root.addView(title("Script → AI video workflow",15));
      Button file=btn("📄 Upload Script (.txt)"); root.addView(file);
      script=new EditText(this);script.setHint("Paste your complete script here...");script.setTextColor(Color.WHITE);script.setHintTextColor(Color.GRAY);script.setGravity(Gravity.TOP);script.setMinLines(9);root.addView(script);
      LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
      Button generate=btn("🎬 Generate Scenes");row.addView(generate,new LinearLayout.LayoutParams(-1,-2));root.addView(row);
      status=title("Ready. This Android app creates your production package.\nActual AI video generation uses an external/free AI service.",13);root.addView(status);
      file.setOnClickListener(v->pickFile());
      generate.setOnClickListener(v->generateScenes());
      setContentView(sv);
    }
    void pickFile(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("text/plain");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,42);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==42&&c==RESULT_OK&&d!=null)try{Uri u=d.getData();InputStream in=getContentResolver().openInputStream(u);BufferedReader br=new BufferedReader(new InputStreamReader(in));StringBuilder s=new StringBuilder();String x;while((x=br.readLine())!=null)s.append(x).append("\n");script.setText(s.toString());}catch(Exception e){status.setText("Could not read file.");}}
    void generateScenes(){
      String t=script.getText().toString().trim();if(t.isEmpty()){status.setText("Please upload or paste a script.");return;}
      String[] p=t.split("\\n\\s*\\n+"); if(p.length==1){String[] w=t.split("\\s+");ArrayList<String>a=new ArrayList<>();for(int i=0;i<w.length;i+=45){StringBuilder s=new StringBuilder();for(int j=i;j<Math.min(i+45,w.length);j++)s.append(w[j]).append(" ");a.add(s.toString().trim());}p=a.toArray(new String[0]);}
      LinearLayout scenes=new LinearLayout(this);scenes.setOrientation(LinearLayout.VERTICAL);
      root.addView(title("SCENES",20));
      for(int i=0;i<p.length;i++){TextView v=title("Scene "+(i+1)+"\n"+p[i]+"\n\nVIDEO PROMPT:\nCinematic realistic scene, consistent character, detailed environment, natural lighting, smooth camera movement. ACTION: "+p[i],13);v.setBackgroundColor(Color.rgb(18,21,27));scenes.addView(v);}
      Button open=btn("🌐 Open Free AI Video Generator");open.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://huggingface.co/spaces/Lightricks/ltx-2-distilled"));startActivity(i);});scenes.addView(open);
      status.setText("Created "+p.length+" scenes. Scroll down to use the AI generator.");
    }
}