# AI Video Maker — Final v5

This build turns a script into a complete vertical MP4 workflow:

1. Paste/upload a Hindi or English script.
2. Generate scenes and cinematic video prompts.
3. Add an optional Hugging Face token if the public LTX Space reports a ZeroGPU quota limit.
4. Choose 1–8 seconds per scene.
5. Tap **MAKE COMPLETE VIDEO**.
6. The app generates scenes through the Lightricks LTX Video 0.9.8 Gradio API, downloads the clips, optionally creates phone TTS narration, and assembles everything into one MP4.
7. The final MP4 is saved in **Movies/AI Video Maker** and can be shared.

The public LTX Space remains subject to Hugging Face's quota/availability. The app does not bypass that quota. A Hugging Face token can authenticate the request for the account's available quota.

## GitHub APK build

Open the repository Actions tab and run **Build AI Video Maker APK**. Download the artifact named `ai-video-maker-final-apk` and install `app-debug.apk`.
