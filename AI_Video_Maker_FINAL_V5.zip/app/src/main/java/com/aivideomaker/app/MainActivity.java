package com.aivideomaker.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.res.Resources;
import android.graphics.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.text.InputType;
import android.view.*;
import android.widget.*;

import androidx.annotation.OptIn;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.EditedMediaItemSequence;
import androidx.media3.transformer.Transformer;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;

import org.json.*;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

@OptIn(markerClass = UnstableApi.class)
public class MainActivity extends Activity {
    private LinearLayout root, scenes;
    private EditText script, token;
    private TextView status;
    private CheckBox narration;
    private SeekBar durationBar;
    private TextView durationLabel;
    private ArrayList<String> prompts = new ArrayList<>();
    private ArrayList<String> narrations = new ArrayList<>();
    private ArrayList<File> clips = new ArrayList<>();
    private ArrayList<File> ttsFiles = new ArrayList<>();
    private boolean busy = false;
    private int durationSeconds = 5;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private int ttsIndex = 0;
    private File pendingFinal;

    private static final String SPACE = "https://lightricks-ltx-video-distilled.hf.space";
    private static final String NEGATIVE = "text, subtitles, watermark, logo, distorted hands, extra fingers, duplicate people, changing face, changing clothes, flicker, jitter";
    private static final int ORANGE = Color.rgb(255, 98, 0);
    private final int white = Color.WHITE;
    private final int muted = Color.rgb(170, 178, 190);

    private TextView tv(String s, int z) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextColor(white);
        v.setTextSize(z);
        v.setPadding(16, 10, 16, 10);
        return v;
    }

    private Button b(String s) {
        Button x = new Button(this);
        x.setText(s);
        x.setAllCaps(false);
        return x;
    }

    @Override public void onCreate(Bundle x) {
        super.onCreate(x);
        initTts();
        buildUi();
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12, 8, 12, 28);
        root.setBackgroundColor(Color.rgb(8, 10, 15));
        ScrollView sv = new ScrollView(this);
        sv.addView(root);

        root.addView(tv("AI VIDEO MAKER — FINAL", 24));
        root.addView(tv("Script → scenes → AI clips → narration → one MP4", 14));

        Button up = b("📄 Upload Script (.txt)");
        root.addView(up);

        script = new EditText(this);
        script.setHint("Paste your complete Hindi/English script here…");
        script.setHintTextColor(Color.GRAY);
        script.setTextColor(white);
        script.setGravity(Gravity.TOP);
        script.setMinLines(10);
        script.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        root.addView(script);

        token = new EditText(this);
        token.setHint("Hugging Face token (optional — helps with quota)");
        token.setHintTextColor(Color.GRAY);
        token.setTextColor(white);
        token.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        token.setSingleLine(true);
        token.setText(getPreferences(MODE_PRIVATE).getString("hf_token", ""));
        root.addView(token);
        root.addView(tv("Create a token at huggingface.co/settings/tokens. Keep it private; it stays on this phone.", 12));

        LinearLayout drow = new LinearLayout(this);
        drow.setOrientation(LinearLayout.VERTICAL);
        durationLabel = tv("Clip duration: 5 seconds", 13);
        drow.addView(durationLabel);
        durationBar = new SeekBar(this);
        durationBar.setMax(7); // 1..8 seconds
        durationBar.setProgress(4);
        drow.addView(durationBar);
        durationBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean from) {
                durationSeconds = p + 1;
                durationLabel.setText("Clip duration: " + durationSeconds + " seconds");
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        root.addView(drow);

        narration = new CheckBox(this);
        narration.setText("🔊 Add narration using phone TTS");
        narration.setTextColor(white);
        narration.setChecked(true);
        root.addView(narration);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button go = b("🎬 Generate Scenes");
        Button auto = b("🚀 MAKE COMPLETE VIDEO");
        row.addView(go, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(auto, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);

        Button combine = b("🎞️ Combine downloaded clips");
        root.addView(combine);

        status = tv("Ready. Public LTX access is quota-limited; add your Hugging Face token if the Space asks for authentication.", 13);
        status.setTextColor(muted);
        root.addView(status);
        scenes = new LinearLayout(this);
        scenes.setOrientation(LinearLayout.VERTICAL);
        root.addView(scenes);

        up.setOnClickListener(v -> pick());
        go.setOnClickListener(v -> generateScenes());
        auto.setOnClickListener(v -> makeCompleteVideo());
        combine.setOnClickListener(v -> { if (clips.size() >= 1) composeFinal(); else status.setText("Generate or download clips first."); });
        setContentView(sv);
    }

    private void initTts() {
        tts = new TextToSpeech(this, result -> {
            ttsReady = result == TextToSpeech.SUCCESS;
            if (ttsReady) tts.setSpeechRate(0.95f);
        });
    }

    private void pick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("text/plain");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, 42);
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (r == 42 && c == RESULT_OK && d != null && d.getData() != null) {
            try (BufferedReader q = new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(d.getData()), StandardCharsets.UTF_8))) {
                StringBuilder s = new StringBuilder();
                String z;
                while ((z = q.readLine()) != null) s.append(z).append('\n');
                script.setText(s.toString());
            } catch (Exception e) { toast("Could not read script file"); }
        }
    }

    private void generateScenes() {
        String t = script.getText().toString().trim();
        if (t.isEmpty()) { status.setText("Please paste/upload a script first."); return; }
        String[] p = t.split("\\n\\s*\\n+");
        if (p.length == 1) {
            String[] w = t.split("\\s+");
            ArrayList<String> a = new ArrayList<>();
            for (int i = 0; i < w.length; i += 45) {
                StringBuilder s = new StringBuilder();
                for (int j = i; j < Math.min(i + 45, w.length); j++) s.append(w[j]).append(' ');
                a.add(s.toString().trim());
            }
            p = a.toArray(new String[0]);
        }
        scenes.removeAllViews(); prompts.clear(); narrations.clear(); clips.clear();
        scenes.addView(tv("SCENES (" + p.length + ")", 21));
        for (int i = 0; i < p.length; i++) scene(i + 1, p[i].trim());
        status.setText("Created " + p.length + " scenes. Tap MAKE COMPLETE VIDEO to generate and assemble them.");
    }

    private void scene(int n, String nar) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(6, 8, 6, 16);
        c.setBackgroundColor(Color.rgb(18, 21, 27));
        c.addView(tv("SCENE " + n, 18));
        c.addView(tv("NARRATION\n" + nar, 14));
        String p = "Cinematic realistic vertical 9:16 video. Consistent recurring character, same face, age, hairstyle, clothing and body proportions. Detailed environment, natural motion, professional camera movement, realistic lighting, shallow depth of field. ACTION: " + nar;
        prompts.add(p); narrations.add(nar);
        c.addView(tv("VIDEO PROMPT\n" + p, 13));
        Button cp = b("📋 COPY VIDEO PROMPT");
        cp.setOnClickListener(v -> copy(p));
        Button one = b("▶ Generate this scene");
        one.setOnClickListener(v -> generateOne(n - 1));
        c.addView(cp); c.addView(one);
        c.addView(tv("NEGATIVE PROMPT\n" + NEGATIVE, 12));
        scenes.addView(c);
    }

    private void makeCompleteVideo() {
        if (prompts.isEmpty()) generateScenes();
        if (prompts.isEmpty() || busy) return;
        busy = true; clips.clear(); ttsFiles.clear();
        getPreferences(MODE_PRIVATE).edit().putString("hf_token", token.getText().toString().trim()).apply();
        new Thread(() -> {
            for (int i = 0; i < prompts.size(); i++) {
                final int k = i;
                ui(() -> status.setText("Generating scene " + (k + 1) + " / " + prompts.size() + "…"));
                try {
                    File f = generateViaApi(prompts.get(i));
                    if (f == null) throw new Exception("No video returned");
                    clips.add(f);
                } catch (Exception e) {
                    busy = false;
                    ui(() -> status.setText("Stopped at scene " + (k + 1) + ": " + cleanError(e.getMessage())));
                    return;
                }
            }
            if (narration.isChecked()) {
                ui(() -> status.setText("AI clips complete. Creating narration…"));
                ui(this::startTtsPipeline);
            } else {
                ui(() -> { status.setText("All clips generated. Assembling final MP4…"); composeFinal(); });
            }
        }).start();
    }

    private void generateOne(int idx) {
        if (busy || idx < 0 || idx >= prompts.size()) return;
        busy = true;
        getPreferences(MODE_PRIVATE).edit().putString("hf_token", token.getText().toString().trim()).apply();
        new Thread(() -> {
            try {
                ui(() -> status.setText("Generating scene " + (idx + 1) + "…"));
                File f = generateViaApi(prompts.get(idx));
                if (f != null) {
                    clips.add(f);
                    ui(() -> status.setText("Scene " + (idx + 1) + " saved. You can generate more or combine clips."));
                } else ui(() -> status.setText("No video returned."));
            } catch (Exception e) { ui(() -> status.setText("Error: " + cleanError(e.getMessage()))); }
            busy = false;
        }).start();
    }

    private File generateViaApi(String prompt) throws Exception {
        JSONObject body = new JSONObject();
        JSONArray a = new JSONArray();
        a.put(prompt);
        a.put(NEGATIVE);
        a.put(JSONObject.NULL); a.put(JSONObject.NULL);
        a.put(512); a.put(704); // portrait-friendly dimensions; both divisible by 32
        a.put("text-to-video");
        a.put((double) durationSeconds);
        a.put(9);
        a.put(new Random().nextInt(Integer.MAX_VALUE));
        a.put(true);
        a.put(3.0);
        a.put(false); // faster single pass for batch generation
        body.put("data", a);

        String auth = token.getText().toString().trim();
        HttpURLConnection c = open(new URL(SPACE + "/gradio_api/call/text_to_video"), "POST", auth);
        c.setDoOutput(true);
        c.getOutputStream().write(body.toString().getBytes(StandardCharsets.UTF_8));
        int code = c.getResponseCode();
        String resp = read(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream());
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + resp);
        JSONObject ev = new JSONObject(resp);
        String id = ev.optString("event_id", "");
        if (id.isEmpty()) throw new Exception("No event id returned: " + resp);

        HttpURLConnection pc = open(new URL(SPACE + "/gradio_api/call/text_to_video/" + URLEncoder.encode(id, "UTF-8")), "GET", auth);
        pc.setRequestProperty("Accept", "text/event-stream");
        String s = read(pc.getInputStream());
        String url = findVideoUrl(s);
        if (url == null) {
            if (s.contains("quota") || s.contains("ZeroGPU")) throw new Exception("Hugging Face quota reached. Add/authenticate a Hugging Face token or wait for quota reset.");
            throw new Exception("Generation finished but no video URL was found.");
        }
        return downloadVideo(url, clips.size() + 1);
    }

    private HttpURLConnection open(URL u, String method, String auth) throws Exception {
        HttpURLConnection c = (HttpURLConnection) u.openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(30000);
        c.setReadTimeout(15 * 60 * 1000);
        c.setRequestProperty("User-Agent", "AI-Video-Maker-Final/5.0");
        if (auth != null && !auth.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + auth);
        return c;
    }

    private String findVideoUrl(String s) {
        Matcher m = Pattern.compile("https?://[^\\s\\\"\\]]+\\.mp4[^\\s\\\"\\]]*", Pattern.CASE_INSENSITIVE).matcher(s);
        if (m.find()) return m.group();
        m = Pattern.compile("\\\"url\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"").matcher(s);
        if (m.find()) return m.group(1).replace("\\/", "/");
        return null;
    }

    private File downloadVideo(String u, int number) throws Exception {
        if (u.startsWith("/")) u = SPACE + u;
        HttpURLConnection c = open(new URL(u), "GET", token.getText().toString().trim());
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) throw new Exception("Video download HTTP " + code);
        File dir = new File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "AI Video Maker/clips");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create clips folder");
        File f = new File(dir, String.format(Locale.US, "scene_%03d_%d.mp4", number, System.currentTimeMillis()));
        try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(f)) {
            byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        }
        return f;
    }

    private void startTtsPipeline() {
        if (!ttsReady) { status.setText("Phone TTS is unavailable. Building silent video instead…"); composeFinal(); return; }
        ttsFiles.clear(); ttsIndex = 0; synthesizeNextTts();
    }

    private void synthesizeNextTts() {
        if (ttsIndex >= narrations.size()) { status.setText("Narration ready. Assembling final MP4…"); composeFinal(); return; }
        String text = narrations.get(ttsIndex);
        if (text.trim().isEmpty()) { ttsIndex++; synthesizeNextTts(); return; }
        try {
            Locale lang = text.matches(".*[\\u0900-\\u097F].*") ? new Locale("hi", "IN") : Locale.US;
            tts.setLanguage(lang);
            File dir = new File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "AI Video Maker/tts");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, String.format(Locale.US, "narration_%03d.wav", ttsIndex + 1));
            ttsFiles.add(f);
            String id = "tts_" + ttsIndex + "_" + System.currentTimeMillis();
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) {}
                @Override public void onDone(String utteranceId) {
                    if (utteranceId.equals(id)) { ttsIndex++; ui(MainActivity.this::synthesizeNextTts); }
                }
                @Override public void onError(String utteranceId) {
                    if (utteranceId.equals(id)) { ttsIndex++; ui(MainActivity.this::synthesizeNextTts); }
                }
            });
            Bundle params = new Bundle();
            int result = tts.synthesizeToFile(text, params, f, id);
            if (result != TextToSpeech.SUCCESS) { ttsIndex++; synthesizeNextTts(); }
        } catch (Exception e) { ttsIndex++; synthesizeNextTts(); }
    }

    private void composeFinal() {
        if (clips.isEmpty()) { busy = false; status.setText("No clips available."); return; }
        if (clips.size() < prompts.size()) {
            status.setText("Combining " + clips.size() + " generated clips. Missing scenes are not invented.");
        }
        final File out = new File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "AI Video Maker/final_video_" + System.currentTimeMillis() + ".mp4");
        File parent = out.getParentFile(); if (parent != null) parent.mkdirs();
        pendingFinal = out;

        try {
            ArrayList<EditedMediaItem> videoItems = new ArrayList<>();
            for (File f : clips) videoItems.add(new EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(f))).build());
            EditedMediaItemSequence videoSequence = EditedMediaItemSequence.withVideoFrom(videoItems);

            ArrayList<EditedMediaItemSequence> sequences = new ArrayList<>();
            sequences.add(videoSequence);

            if (narration.isChecked() && !ttsFiles.isEmpty()) {
                EditedMediaItemSequence.Builder ab = new EditedMediaItemSequence.Builder(Collections.singleton(C.TRACK_TYPE_AUDIO));
                int count = Math.min(clips.size(), ttsFiles.size());
                for (int i = 0; i < count; i++) {
                    long videoUs = mediaDurationUs(clips.get(i));
                    long audioUs = mediaDurationUs(ttsFiles.get(i));
                    if (videoUs <= 0 || audioUs <= 0) continue;
                    long useUs = Math.min(videoUs, audioUs);
                    MediaItem mi = new MediaItem.Builder().setUri(Uri.fromFile(ttsFiles.get(i)))
                            .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder().setEndPositionMs(useUs / 1000).build())
                            .build();
                    ab.addItem(new EditedMediaItem.Builder(mi).build());
                    if (videoUs > useUs) ab.addGap(videoUs - useUs);
                }
                try { sequences.add(ab.build()); } catch (Exception ignored) {}
            }

            Composition composition = new Composition.Builder(sequences).build();
            Transformer transformer = new Transformer.Builder(this)
                    .addListener(new Transformer.Listener() {
                        @Override public void onCompleted(Composition c, ExportResult result) {
                            ui(() -> publishFinal(out));
                        }
                        @Override public void onError(Composition c, ExportResult result, ExportException e) {
                            busy = false;
                            ui(() -> status.setText("Final assembly error: " + cleanError(e.getMessage())));
                        }
                    }).build();
            status.setText("Assembling " + clips.size() + " clips into one MP4…");
            transformer.start(composition, out.getAbsolutePath());
        } catch (Exception e) {
            busy = false;
            status.setText("Assembly error: " + cleanError(e.getMessage()));
        }
    }

    private long mediaDurationUs(File f) {
        android.media.MediaMetadataRetriever r = new android.media.MediaMetadataRetriever();
        try { r.setDataSource(f.getAbsolutePath()); String d = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION); return d == null ? 0 : Long.parseLong(d) * 1000L; }
        catch (Exception e) { return 0; } finally { try { r.release(); } catch (Exception ignored) {} }
    }

    private void publishFinal(File out) {
        try {
            String name = out.getName();
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Video.Media.DISPLAY_NAME, name);
                v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
                v.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AI Video Maker");
                v.put(MediaStore.Video.Media.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new IOException("MediaStore insert failed");
                try (InputStream in = new FileInputStream(out); OutputStream os = getContentResolver().openOutputStream(uri)) {
                    byte[] buf = new byte[16384]; int n; while ((n = in.read(buf)) != -1) os.write(buf, 0, n);
                }
                ContentValues done = new ContentValues(); done.put(MediaStore.Video.Media.IS_PENDING, 0); getContentResolver().update(uri, done, null, null);
                busy = false;
                status.setText("✅ COMPLETE VIDEO SAVED to Movies/AI Video Maker");
                addShareButton(uri);
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES + "/AI Video Maker");
                if (!dir.exists()) dir.mkdirs();
                File pub = new File(dir, name);
                copyFile(out, pub);
                sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(pub)));
                busy = false; status.setText("✅ COMPLETE VIDEO SAVED to Movies/AI Video Maker");
                addShareButton(Uri.fromFile(pub));
            }
        } catch (Exception e) { busy = false; status.setText("Final video created but gallery save failed: " + cleanError(e.getMessage())); }
    }

    private void addShareButton(Uri uri) {
        Button share = b("📤 Share final video");
        share.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_SEND); i.setType("video/mp4"); i.putExtra(Intent.EXTRA_STREAM, uri); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(Intent.createChooser(i, "Share video"));
        });
        scenes.addView(share, 0);
    }

    private void copyFile(File a, File b) throws Exception {
        try (InputStream in = new FileInputStream(a); OutputStream out = new FileOutputStream(b)) { byte[] buf = new byte[16384]; int n; while ((n = in.read(buf)) != -1) out.write(buf, 0, n); }
    }

    private String read(InputStream in) throws Exception {
        if (in == null) return "";
        BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder s = new StringBuilder(); String line; while ((line = r.readLine()) != null) s.append(line).append('\n'); return s.toString();
    }

    private String cleanError(String e) {
        if (e == null) return "Unknown error";
        if (e.length() > 500) e = e.substring(0, 500);
        return e.replace("\\n", " ").replace("\\r", " ");
    }

    private void copy(String s) { ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("prompt", s)); toast("Prompt copied"); }
    private void toast(String s) { ui(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show()); }
    private void ui(Runnable r) { runOnUiThread(r); }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
