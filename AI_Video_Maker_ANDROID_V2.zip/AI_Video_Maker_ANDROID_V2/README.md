AI Video Maker V2: fixed scene rendering, per-scene copy buttons, script upload, LTX-2 link.
